# Android Calc Layout
