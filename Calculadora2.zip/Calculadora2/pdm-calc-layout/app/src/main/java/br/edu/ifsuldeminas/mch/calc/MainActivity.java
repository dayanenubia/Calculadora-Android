package br.edu.ifsuldeminas.mch.calc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import de.congrace.exp4j.Calculable;
import de.congrace.exp4j.ExpressionBuilder;
import de.congrace.exp4j.UnknownFunctionException;
import de.congrace.exp4j.UnparsableExpressionException;

public class MainActivity extends Activity implements View.OnClickListener {

    //Declarando variaveis
    private Button buttonZeroID, buttonUmID, buttonDoisID, buttonTresID, buttonQuatroID, buttonCincoID,
            buttonSeisID, buttonSeteID, buttonOitoID, buttonNoveID, buttonSomaID, buttonSubtracaoID,
            buttonPorcentoID, buttonMultiplicacaoID, buttonDivisaoID, buttonVirgulaID, buttonResetID, buttonDeleteID, buttonIgual;
    private TextView textViewResultado;
    private TextView textViewUltimaExpressao ;
    private Double resultado = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //getSupportActionBar().hide();

        textViewResultado = findViewById(R.id.textViewResultadoID);
        textViewUltimaExpressao = findViewById(R.id.textViewUltimaExpressaoID);

        // Encontra o botão "0" no layout XML pelo seu ID e associa-o à variável buttonZeroID
        buttonZeroID = findViewById(R.id.buttonZeroID);
        // Define um novo ouvinte de clique para o botão "0" usando uma classe anônima
        buttonZeroID.setOnClickListener(new View.OnClickListener() {
            @Override
            // Adiciona o caractere "0" ao final do conteúdo atual do TextView "textViewUltimaExpressao"
            public void onClick(View view) {
                textViewUltimaExpressao.append("0");
            }
        });

        //Encontrando o Botão 1 no layout e associando ao ID | Add o valor 1 ao final do conteudo atual
        buttonUmID = findViewById(R.id.buttonUmID);
        buttonUmID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("1");
            }
        });

        //Encontrando o Botão 2 no layout e associando ao ID | Add o valor 2 ao final do conteudo atual
        buttonDoisID = findViewById(R.id.buttonDoisID);
        buttonDoisID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("2");
            }
        });

        //Encontrando o Botão 3 no layout e associando ao ID | Add o valor 3 ao final do conteudo atual
        buttonTresID = findViewById(R.id.buttonTresID);
        buttonTresID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("3");
            }
        });

        //Encontrando o Botão 4 no layout e associando ao ID | Add o valor 4 ao final do conteudo
        buttonQuatroID = findViewById(R.id.buttonQuatroID);
        buttonQuatroID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("4");
            }
        });

        //Encontrando o Botão 5 no layout e associando ao ID | Add o valor 5 ao final do conteudo
        buttonCincoID = findViewById(R.id.buttonCincoID);
        buttonCincoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("5");
            }
        });

        //Encontrando o Botão 6 no layout e associando ao ID | Add o valor 6 ao final do conteudo
        buttonSeisID = findViewById(R.id.buttonSeisID);
        buttonSeisID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("6");
            }
        });

        //Encontrando o Botão 7 no layout e associando ao ID | Add o valor 7 ao final do conteudo
        buttonSeteID = findViewById(R.id.buttonSeteID);
        buttonSeteID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("7");
            }
        });

        //Encontrando o Botão 8 no layout e associando ao ID | Add o valor 8 ao final do conteudo
        buttonOitoID = findViewById(R.id.buttonOitoID);
        buttonOitoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("8");
            }
        });

        //Encontrando o Botão 9 no layout e associando ao ID | Add o valor 9 ao final do conteudo
        buttonNoveID = findViewById(R.id.buttonNoveID);
        buttonNoveID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("9");
            }
        });

        //Encontrando o Botão + no layout e associando ao ID | Add o sinal de + ao final do conteudo
        buttonSomaID = findViewById(R.id.buttonSomaID);
        buttonSomaID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("+");
            }
        });

        //Encontrando o Botão - no layout e associando ao ID | Add o sinal de - ao final do conteudo
        buttonSubtracaoID = findViewById(R.id.buttonSubtracaoID);
        buttonSubtracaoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("-");
            }
        });

        //Encontrando o Botão % no layout e associando ao ID | Add o sinal de % ao final do conteudo
        buttonPorcentoID = findViewById(R.id.buttonPorcentoID);
        buttonPorcentoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("%");
            }
        });

        //Encontrando o Botão * no layout e associando ao ID | Add o sinal de * ao final do conteudo
        buttonMultiplicacaoID = findViewById(R.id.buttonMultiplicacaoID);
        buttonMultiplicacaoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("*");
            }
        });

        //Encontrando o Botão / no layout e associando ao ID | Add o sinal de / ao final do conteudo
        buttonDivisaoID = findViewById(R.id.buttonDivisaoID);
        buttonDivisaoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append("/");
            }
        });

        //Encontrando o Botão , no layout e associando ao ID | Add o sinal de , ao final do conteudo
        buttonVirgulaID = findViewById(R.id.buttonVirgulaID);
        buttonVirgulaID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.append(".");
            }
        });

        //Encontrando o Botão Reset no layout e associando ao ID | Add o sinal de C ao final do conteudo
        buttonResetID = findViewById(R.id.buttonResetID);
        buttonResetID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewUltimaExpressao.setText("");
                textViewResultado.setText("");
            }
        });

        //Encontrando o Botão Delete no layout e associando ao ID | Add o sinal de D ao final do conteudo
        buttonDeleteID = findViewById(R.id.buttonDeleteID);
        buttonDeleteID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Criando um objeto apartir da expressao atual
                StringBuilder sb = new StringBuilder(textViewUltimaExpressao.getText().toString());
                //Verificando se existe algum valor na expressao para ser apagado
                if (sb.length() > 0) {
                    //Deletando o ultimo caractere
                    sb.deleteCharAt(sb.length() - 1);
                    //Substituindo a string original com a nova (sem o ultimo caractere)
                    textViewUltimaExpressao.setText(sb.toString());
                }
            }
        });

        //Encontrando o Botão = no layout e associando ao ID
        buttonIgual = findViewById(R.id.buttonIgualID);
        buttonIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Verifica o Id do botão clicado
                if (view.getId() == R.id.buttonIgualID) {
                    //Resgata o valor atual da expressao
                    String expressao = textViewUltimaExpressao.getText().toString();
                    try {
                        //Cria um objeto apartir da expressao
                        Calculable calculo = new ExpressionBuilder(expressao).build();
                        //Calcula o resultado da expresao, se for possivel
                        resultado = calculo.calculate();
                        //Exibe o resultado
                        textViewResultado.setText(resultado.toString());
                    } catch (UnparsableExpressionException | UnknownFunctionException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override
    public void onClick(View view) {

    }
}